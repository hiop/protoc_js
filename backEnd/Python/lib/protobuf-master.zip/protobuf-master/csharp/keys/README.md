Contents
--------

- Google.Protobuf.public.snk:
  Public key to verify strong name of Google.Protobuf assemblies.